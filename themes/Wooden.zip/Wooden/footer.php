	</div>
</div>

<div id="footer"><?php _e('Designed by ','Wooden'); ?> <a href="http://www.elegantthemes.com" title="Elegant Themes">Elegant Themes</a> | <?php _e('Powered by ','Wooden'); ?> <a href="http://www.wordpress.org">Wordpress</a></div>
	
<?php include(TEMPLATEPATH . '/includes/scripts.php'); ?>
<?php wp_footer(); ?>	
