		<div id="footer">
			<?php _e('Designed by ','Quadro'); ?> <a href="http://www.elegantthemes.com" title="Elegant Themes">Elegant Themes</a> | <?php _e('Powered by ','Quadro'); ?> <a href="http://www.wordpress.org">Wordpress</a>
		</div> <!-- end #footer -->
	</div> <!-- end #wrapper2 -->
</div> <!-- end #bg -->

<?php include(TEMPLATEPATH . '/includes/scripts.php'); ?>
<?php wp_footer(); ?>